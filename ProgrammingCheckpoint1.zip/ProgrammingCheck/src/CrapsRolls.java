/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rachita
 */
public class CrapsRolls {
    
    private int rounds=0;
    private int rolls=0;
    private int point=0;
    private int wins=0;
    private int losses=0;
    private String winLoss;
    private int diceX=0;
    private int diceY=0;
    private int sum1 = 0; 
    

/**
     * Details number of wins
     * @return wins
     */
       public  int getWins() {
        return wins;
}
 /**
     * Details number of losses
     * @return losses
     */   
             public  int getLosses() {
        return losses;
}
 /**
     * Prints win or loss for the first 10 rounds
     * @param winLoss1 details whether output is win or loss
     */            
public  void printWinLoss(String winLoss1) {
    winLoss=winLoss1;
     if(rounds <=10)  {
        System.out.println(winLoss);
               }
}
 /**
     * Prints overall summary of each rounds rolls and progress
     * 
     */   
public  void printRoundsRolls() {
     if(rounds <=10)  {
  System.out.println("Round: " + rounds + ", Roll: " + rolls + " -- " + "Die1: " + diceX +" , " +
                                               "Die2: " + diceY + " -- " + "Total: " + sum1);
   if(rolls==1)  {
          point=sum1;
          System.out.println("Point is " + point); 
  }
  }
}


 /**
     * executes dice roll/sum and executes logic for how to declare whether a certain sum is a win or loss
     * @param rounds number of rounds that will be executed
     */   
public  void rolls(int rounds) {
    this.rounds=rounds;
    rolls=0;
  while (true)  
{ 
//dice roll to gather sum
     rolls++;
     diceX=(int)(Math.random()*6+1); 
     diceY=(int)(Math.random()*6+1); 
     sum1 = diceX + diceY; 
     printRoundsRolls();

  
/****Main logic start here ****/
//if sum is 2,3,12 then LOSS
  if ((rolls==1)&&(sum1==2 || sum1==3 || sum1==12)) {       
         printWinLoss("LOSS!");
         losses++;
         break; 
//if sum is 7,11 then WIN
  } else if ((rolls==1)&&(sum1==7 || sum1==11)) {  
          printWinLoss("WIN!");
          wins++;
          break;  
//compare point to subsequent roll values to determine whether win or loss
  } else if ((rolls != 1)&&(sum1==7 || sum1==point)) {  
           if(sum1==point){
                printWinLoss("WIN!");
                wins++;
                break;  
           } else if(sum1==7){
                     printWinLoss("LOSS!");
                     losses=losses + 1;
                     break; }
           
  }
  /****Main logic End here ****/
  
}
  } 
    
}
