/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rachita
 */
public class CrapRounds {
    int rounds=0;
    
     /**
     * Executes loops which result in number of wins/losses and 10 rounds with a total of specified rounds
     * @param numRounds details how many rounds will be executed
     */   
    public void numRounds(int numRounds) {
    CrapsRolls objRef=new CrapsRolls();
   //number of rounds that will be executed in TOTAL
    for (int i = 0; i < numRounds; i++) { 
    rounds++;
    
    objRef.rolls(rounds);
   //prints details for first 10 rounds
        if(rounds<=10)  {
            System.out.println(objRef.getWins() + " wins(s) , " + objRef.getLosses() + " loss(es)"); 
    
         }
    }
       System.out.println("OVERALL:"); 
       System.out.println(objRef.getWins() + " wins(s) , " + objRef.getLosses() + " loss(es)");
}

    
}
